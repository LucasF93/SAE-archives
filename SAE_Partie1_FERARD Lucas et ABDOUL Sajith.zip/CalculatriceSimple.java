public class CalculatriceSimple {
    public static void main(String[] args) {
        Nombre six = new Nombre(6);
        Nombre dix = new Nombre(10);
        
        // Test de la soustraction
        try {
            Operation s = new Soustraction(dix, six);
            System.out.println(s); // doit afficher : (10 – 6) = 4
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de la soustraction : " + e.getMessage());
        }

        // Test de l'addition
        try {
            Operation a = new Addition(dix, six);
            System.out.println(a); // doit afficher : (10 + 6) = 16
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de l'addition : " + e.getMessage());
        }
        
        // Test de la multiplication
        try {
            Operation m = new Multiplication(dix, six);
            System.out.println(m); // doit afficher : (10 * 6) = 60
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de la multiplication : " + e.getMessage());
        }
        
        // Test de la division
        try {
            Operation d = new Division(dix, six);
            System.out.println(d); // doit afficher : (10 / 6) = 1
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de la division : " + e.getMessage());
        }
    }
}
