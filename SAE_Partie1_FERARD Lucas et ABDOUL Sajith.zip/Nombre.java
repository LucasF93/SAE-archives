public class Nombre {
    private int valeurNombre;

    public Nombre(int unNombre) {
        this.valeurNombre = unNombre;
    }

    public int valeur() {
        return this.valeurNombre;
    }

    public String toString() {
        return "nombre : " + this.valeurNombre;
    }
}
