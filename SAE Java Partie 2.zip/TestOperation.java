public class TestOperation {
   
    public static void main(String[] args) {
        Expression deux = new Nombre(2);
        Expression trois = new Nombre(3);
        Expression dixSept = new Nombre(17);

        // Test de la soustraction
        try {
            Expression s = new Soustraction(dixSept, deux);
            System.out.println(s + " = " + s.valeur()); // doit afficher (17 - 2) = 15
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de la soustraction : " + e.getMessage());
        }
        // Test de l'adddition
        try {
            Expression a = new Addition(deux, trois);
            System.out.println(a + " = " + a.valeur()); // doit afficher (2 + 3) = 5
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de l'addition : " + e.getMessage());
        }
        // Test de la multiplication
        try {
            Expression m = new Multiplication(trois, deux);
            System.out.println(m + " = " + m.valeur()); // doit afficher (3 * 2) = 6
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de la multiplication : " + e.getMessage());
        }
        // Test de la division
        try {
            Expression d = new Division(new Soustraction(dixSept, deux), new Addition(deux, trois));
            System.out.println(d + " = " + d.valeur()); // doit afficher ((17 - 2) = 15 / (2 + 3) = 5 ) donc 15/3 = 3
        } catch (ArithmeticException e) {
            System.out.println("Erreur lors de la division : " + e.getMessage());
        }

        // Test a) si e est «3»
        Expression testA = fabriqueExpression("3");
        System.out.println("Test a) : " + testA + " = " + testA.valeur());

        // Test b) si e est «17-2»
        Expression testB = fabriqueExpression("17-2");
        System.out.println("Test b) : " + testB + " = " + testB.valeur());

        // Test c) si e est « (17-2)/3 »
        Expression testC = fabriqueExpression("(17-2)/3");
        System.out.println("Test c) : " + testC + " = " + testC.valeur());
    }

    public static Expression fabriqueExpression(String e) {
        e = e.replaceAll("\\s", ""); // Supprimer les espaces dans la chaîne

        if (e.matches("\\d+")) {
            return new Nombre(Integer.parseInt(e));
        }

        int index = trouverIndexOperation(e);
        if (index != -1) {
            String gauche = e.substring(0, index);
            String droite = e.substring(index + 1);
            char operateur = e.charAt(index);
            switch (operateur) {
                case '+':
                    return new Addition(fabriqueExpression(gauche), fabriqueExpression(droite));
                case '-':
                    return new Soustraction(fabriqueExpression(gauche), fabriqueExpression(droite));
                case '*':
                    return new Multiplication(fabriqueExpression(gauche), fabriqueExpression(droite));
                case '/':
                    return new Division(fabriqueExpression(gauche), fabriqueExpression(droite));
                default:
                    throw new IllegalArgumentException("Opérateur invalide : " + operateur);
            }
        }

        throw new IllegalArgumentException("Expression invalide : " + e);
    }

    private static int trouverIndexOperation(String e) {
        int balance = 0;
        for (int i = 0; i < e.length(); i++) {
            if (e.charAt(i) == '(') {
                balance++;
            } else if (e.charAt(i) == ')') {
                balance--;
            } else if (balance == 0 && (e.charAt(i) == '+' || e.charAt(i) == '-' || e.charAt(i) == '*' || e.charAt(i) == '/')) {
                return i;
            }
        }
        return -1;
    }
}
